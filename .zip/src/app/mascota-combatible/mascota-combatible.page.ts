import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mascota-combatible',
  templateUrl: './mascota-combatible.page.html',
  styleUrls: ['./mascota-combatible.page.scss'],
})
export class MascotaCombatiblePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
